// Lightweight bootstrap that starts the backend server
require('./backend/server.js');
