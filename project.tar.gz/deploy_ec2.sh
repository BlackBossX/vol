#!/bin/bash
set -e

# Configuration
APP_NAME="voldata-bx"
AWS_REGION="ap-south-1"
KEY_NAME="dec-16-login"
KEY_FILE="./dec-16-login.pem"
INSTANCE_TYPE="t3.micro" # Changed to t3.micro for Free Tier eligibility
SG_NAME="${APP_NAME}-sg"

# Ensure key permissions are strict
chmod 400 "$KEY_FILE"

echo "--- Starting Deployment (Build on EC2) ---"

# 1. Security Group
echo "1. Setting up Security Group..."
VPC_ID=$(aws ec2 describe-vpcs --filters Name=isDefault,Values=true --query "Vpcs[0].VpcId" --output text --region $AWS_REGION)
SG_ID=$(aws ec2 describe-security-groups --filters Name=group-name,Values=$SG_NAME --query "SecurityGroups[0].GroupId" --output text --region $AWS_REGION)

if [ "$SG_ID" == "None" ]; then
    SG_ID=$(aws ec2 create-security-group --group-name $SG_NAME --description "Security group for $APP_NAME" --vpc-id $VPC_ID --query GroupId --output text --region $AWS_REGION)
    # Allow SSH, HTTP (80), and App Port (3000)
    aws ec2 authorize-security-group-ingress --group-id $SG_ID --protocol tcp --port 22 --cidr 0.0.0.0/0 --region $AWS_REGION
    aws ec2 authorize-security-group-ingress --group-id $SG_ID --protocol tcp --port 80 --cidr 0.0.0.0/0 --region $AWS_REGION
    aws ec2 authorize-security-group-ingress --group-id $SG_ID --protocol tcp --port 3000 --cidr 0.0.0.0/0 --region $AWS_REGION
    echo "Created Security Group: $SG_ID"
else
    echo "Security Group $SG_NAME already exists ($SG_ID)"
    # Ensure ports are open (idempotent)
    aws ec2 authorize-security-group-ingress --group-id $SG_ID --protocol tcp --port 80 --cidr 0.0.0.0/0 --region $AWS_REGION 2>/dev/null || true
    aws ec2 authorize-security-group-ingress --group-id $SG_ID --protocol tcp --port 3000 --cidr 0.0.0.0/0 --region $AWS_REGION 2>/dev/null || true
fi

# 2. Launch EC2
echo "2. Launching EC2 Instance..."
# Get latest Amazon Linux 2023 AMI
AMI_ID=$(aws ec2 describe-images --owners amazon --filters "Name=name,Values=al2023-ami-2023.*-x86_64" "Name=state,Values=available" --query "sort_by(Images, &CreationDate)[-1].ImageId" --output text --region $AWS_REGION)

# User Data: Install Docker and add ec2-user to docker group
USER_DATA=$(cat <<EOF
#!/bin/bash
dnf update -y
dnf install -y docker
systemctl enable --now docker
usermod -aG docker ec2-user
EOF
)

INSTANCE_ID=$(aws ec2 run-instances \
    --image-id $AMI_ID \
    --count 1 \
    --instance-type $INSTANCE_TYPE \
    --key-name $KEY_NAME \
    --security-group-ids $SG_ID \
    --user-data "$USER_DATA" \
    --tag-specifications "ResourceType=instance,Tags=[{Key=Name,Value=$APP_NAME}]" \
    --query "Instances[0].InstanceId" \
    --output text \
    --region $AWS_REGION)

echo "Instance launched: $INSTANCE_ID"
echo "Waiting for instance to be running..."
aws ec2 wait instance-running --instance-ids $INSTANCE_ID --region $AWS_REGION
PUBLIC_IP=$(aws ec2 describe-instances --instance-ids $INSTANCE_ID --query "Reservations[0].Instances[0].PublicIpAddress" --output text --region $AWS_REGION)
echo "Instance Public IP: $PUBLIC_IP"

# 3. Prepare Code
echo "3. Packaging code..."
# Create tarball excluding heavy/local folders
tar --exclude='node_modules' --exclude='venv' --exclude='__pycache__' --exclude='.git' --exclude='*.pem' --exclude='*.tar.gz' -czf project.tar.gz .

# 4. Deploy
echo "4. Waiting for SSH to be ready..."
# Loop until SSH is available
MAX_RETRIES=30
COUNT=0
while [ $COUNT -lt $MAX_RETRIES ]; do
    ssh -o StrictHostKeyChecking=no -o ConnectTimeout=5 -i "$KEY_FILE" ec2-user@$PUBLIC_IP "echo ready" >/dev/null 2>&1 && break
    echo "   ...waiting for SSH ($COUNT/$MAX_RETRIES)"
    sleep 5
    COUNT=$((COUNT+1))
done

echo "5. Uploading code to EC2..."
scp -o StrictHostKeyChecking=no -i "$KEY_FILE" project.tar.gz ec2-user@$PUBLIC_IP:/home/ec2-user/

echo "6. Building and Running on EC2..."
ssh -o StrictHostKeyChecking=no -i "$KEY_FILE" ec2-user@$PUBLIC_IP << 'ENDSSH'
    # Wait for docker daemon
    echo "Checking Docker status..."
    while ! systemctl is-active --quiet docker; do echo "Waiting for Docker daemon..."; sleep 2; done
    
    # Clean up previous runs
    docker stop voldata-bx 2>/dev/null || true
    docker rm voldata-bx 2>/dev/null || true
    
    # Unpack code
    rm -rf app
    mkdir -p app
    tar -xzf project.tar.gz -C app
    cd app
    
    # Build Image
    echo "Building Docker image on EC2 (this may take a few minutes)..."
    docker build -t voldata-bx .
    
    # Run Container
    # Mapping port 80 on host to 3000 in container
    echo "Starting container..."
    docker run -d --name voldata-bx --restart always -p 80:3000 -e PORT=3000 voldata-bx
ENDSSH

# Cleanup
rm project.tar.gz

echo "--------------------------------------------------"
echo "Deployment Complete!"
echo "App URL: http://$PUBLIC_IP"
echo "SSH Command: ssh -i \"$KEY_FILE\" ec2-user@$PUBLIC_IP"
echo "--------------------------------------------------"
