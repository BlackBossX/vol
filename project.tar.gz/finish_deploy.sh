#!/bin/bash
set -e

PUBLIC_IP="15.207.71.244"
KEY_FILE="./dec-16-login.pem"

echo "--- Finishing Deployment ---"
echo "Target IP: $PUBLIC_IP"

# 4. Wait for SSH
echo "Waiting for SSH..."
MAX_RETRIES=30
COUNT=0
while [ $COUNT -lt $MAX_RETRIES ]; do
    ssh -o StrictHostKeyChecking=no -o ConnectTimeout=5 -i "$KEY_FILE" ec2-user@$PUBLIC_IP "echo ready" >/dev/null 2>&1 && break
    echo "   ...waiting ($COUNT/$MAX_RETRIES)"
    sleep 5
    COUNT=$((COUNT+1))
done

if [ $COUNT -eq $MAX_RETRIES ]; then
    echo "SSH timed out. Check Security Group or Instance status."
    exit 1
fi

# 5. Upload
echo "Uploading code..."
# Ensure tarball exists
if [ ! -f project.tar.gz ]; then
    tar --exclude='node_modules' --exclude='venv' --exclude='__pycache__' --exclude='.git' --exclude='*.pem' --exclude='*.tar.gz' -czf project.tar.gz .
fi

scp -o StrictHostKeyChecking=no -i "$KEY_FILE" project.tar.gz ec2-user@$PUBLIC_IP:/home/ec2-user/

# 6. Build and Run
echo "Building and Running on EC2..."
ssh -o StrictHostKeyChecking=no -i "$KEY_FILE" ec2-user@$PUBLIC_IP << 'ENDSSH'
    # Wait for docker daemon
    echo "Checking Docker status..."
    while ! systemctl is-active --quiet docker; do echo "Waiting for Docker daemon..."; sleep 2; done
    
    # Clean up previous runs
    docker stop voldata-bx 2>/dev/null || true
    docker rm voldata-bx 2>/dev/null || true
    
    # Unpack code
    rm -rf app
    mkdir -p app
    tar -xzf project.tar.gz -C app
    cd app
    
    # Build Image
    echo "Building Docker image on EC2 (this may take a few minutes)..."
    docker build -t voldata-bx .
    
    # Run Container
    echo "Starting container..."
    docker run -d --name voldata-bx --restart always -p 80:3000 -e PORT=3000 voldata-bx
ENDSSH

echo "--------------------------------------------------"
echo "Deployment Complete!"
echo "App URL: http://$PUBLIC_IP"
echo "SSH Command: ssh -i \"$KEY_FILE\" ec2-user@$PUBLIC_IP"
echo "--------------------------------------------------"
